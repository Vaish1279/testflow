Use correct-demo.js for a mostly clean code test.
Use wrong-demo.js to trigger eval(), console and TODO warnings.
