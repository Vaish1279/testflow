function calculateTotal(price, quantity) {
  if (price < 0 || quantity < 0) return 0;
  const total = price * quantity;
  return Number(total.toFixed(2));
}
function formatResult(total) {
  return `Total: ₹${total}`;
}
module.exports = { calculateTotal, formatResult };
