function calculateTotal(price, quantity) {
  if (price < 0) return price * quantity;
  return eval('price * quantity');
}
function saveResult(value) {
  console.log('debug', value);
  // TODO: validate value before saving
}
