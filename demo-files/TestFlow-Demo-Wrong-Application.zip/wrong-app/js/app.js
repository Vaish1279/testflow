function addTask(){
  const value=document.getElementById('task').value;
  if(value){document.getElementById('list').innerHTML+='<p>'+value+'</p>';}
  else{console.log('empty');}
  eval('console.log("debug")');
}
// TODO: add validation
