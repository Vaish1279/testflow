const form=document.querySelector('#taskForm');
const input=document.querySelector('#task');
const list=document.querySelector('#taskList');
form.addEventListener('submit',event=>{
  event.preventDefault();
  const value=input.value.trim();
  if(!value)return;
  const item=document.createElement('li');
  item.textContent=value;
  list.appendChild(item);
  form.reset();
});
